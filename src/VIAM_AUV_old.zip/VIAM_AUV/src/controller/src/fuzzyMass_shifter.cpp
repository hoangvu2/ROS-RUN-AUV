#include "fuzzyMass_shifter.h"


#define pi 3.14159

float SAMPLE_TIME = 10;		 	//(ms)
uint8_t _sample_count = 1;
float speed_mass_min = 5;
float Xsen_Min = -1.0467;
float Xsen_Max = 1.0467;
float THETA_MIN = -45;			//(do)
float THETA_MAX = 45;
float THETADOT_MIN = -10;		//(do/s)
float THETADOT_MAX = 10;
float K1 = 0;
float K2 = 0;
float Ku = 0;
float mass_position = 0;

union Data_In xsen_angle_in, offset_out;
float theta_in, pre_theta_in, thetadot_in;
float offset_defuzzy;
double theta_filtered, theta_dot_filetered;
static bool first_data_pass = true;

struct
{
	double NB;
	double NS;
	double ZE;
	double PB;
	double PS;
}muy_theta, muy_thetadot;

struct
{
	double NVB;
	double NB;
	double NM;
	double NS;
	double ZE;
	double PS;
	double PM;
	double PB;
	double PVB;
}offset, muy_offset, sum;

struct
{
	double C1;
	double C2;
}theta, thetadot;


void Membership_Function_Declaration(void)
{
	//gain
	K1 = 1/THETA_MAX;
	K2 = 1/THETADOT_MAX;
	Ku = 150;
	
	//theta
	theta.C1 = 0.33;
	theta.C2 = 0.66;
	
	//thetadot
	thetadot.C1 = 0.33;
	thetadot.C2 = 0.66;
	
	//offset
	offset.PVB = 1;
	offset.PB = 0.75;
	offset.PM = 0.5;
	offset.PS = 0.25;
	offset.ZE = 0;
	offset.NS = -offset.PS;
	offset.NM = -offset.PM;
	offset.NB = -offset.PB;
	offset.NVB = -offset.PVB;
}

float x2xdot(float x, float pre_x)
{
	return float((x - pre_x))/(SAMPLE_TIME*0.001);
}

static double Fuzzy_Trapzoid(double x, double L, double C1, double C2, double R)
{
	float temp;
	if(x <= L)
	{
		temp = 0;
	}
	else if(x > L && x < C1)
	{   
		temp = float((x - L))/(C1 - L);
	}
	else if(x >= C1 && x <= C2)
	{
		temp = 1;
	}
	else if(x > C2 && x < R)
	{ 
		
		temp = float((R - x))/(R - C2);
	}
	else if(x >= R)
	{
		temp = 0;
	}
	return temp;
}

void Fuzzy_Result(double x1, double x2)
{
	muy_theta.NB = Fuzzy_Trapzoid(x1,-2,-1,-theta.C2,-theta.C1);
	muy_theta.NS = Fuzzy_Trapzoid(x1,-theta.C2,-theta.C1,-theta.C1,0);
	muy_theta.ZE = Fuzzy_Trapzoid(x1,-theta.C1,0,0,theta.C1);
	muy_theta.PS = Fuzzy_Trapzoid(x1,0,theta.C1,theta.C1,theta.C2);
	muy_theta.PB = Fuzzy_Trapzoid(x1,theta.C1,theta.C2,1,2);

	muy_thetadot.NB = Fuzzy_Trapzoid(x2,-2,-1,-theta.C2,-theta.C1);
	muy_thetadot.NS = Fuzzy_Trapzoid(x2,-theta.C2,-theta.C1,-theta.C1,0);
	muy_thetadot.ZE = Fuzzy_Trapzoid(x2,-theta.C1,0,0,theta.C1);
	muy_thetadot.PS = Fuzzy_Trapzoid(x2,0,theta.C1,theta.C1,theta.C2);
	muy_thetadot.PB = Fuzzy_Trapzoid(x2,theta.C1,theta.C2,1,2);
}

static double min(double x, double y)
{
	if(x > y)
		return y;
	else
		return x;
}

static float Fuzzy_Map(float x, float in_min, float in_max, float out_min, float out_max) 
{
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}	

static void Control_Laws(Defuzzy_And_Or_Method method, double x1, double x2,int8_t y)
{
	double temp = 0;
	if(method == MAX_MIN)
	{
		temp = min(x1,x2);
	}
	else if(method == MAX_PROD)
	{
		temp = x1*x2;
	}
	switch(y)
	{
		case NVB:
			if(temp > muy_offset.NVB)
				muy_offset.NVB = temp;
			sum.NVB += temp;
		break;
		case NB:
			if(temp > muy_offset.NB)
				muy_offset.NB = temp;
			sum.NB += temp;
		break;
		case NM:
			if(temp > muy_offset.NM)
				muy_offset.NM = temp;
			sum.NM += temp;
		break;
		case NS:
			if(temp > muy_offset.NS)
				muy_offset.NS = temp;
			sum.NS += temp;
		break;
		case ZE:
			if(temp > muy_offset.ZE)
				muy_offset.ZE = temp;
			sum.ZE += temp;
		break;
		case PS:
			if(temp > muy_offset.PS)
				muy_offset.PS = temp;
			sum.PS += temp;
		break;
		case PM:
			if(temp > muy_offset.PM)
				muy_offset.PM = temp;
			sum.PM += temp;
		break;
		case PB:
			if(temp > muy_offset.PB)
				muy_offset.PB = temp;
			sum.PB += temp;
		break;
		case PVB:
			if(temp > muy_offset.PVB)
				muy_offset.PVB = temp;
			sum.PVB += temp;
		break;
	}

}

float Defuzzy_Result(Defuzzy_And_Or_Method method)
{
	Control_Laws(method,muy_theta.NB,muy_thetadot.NB,PVB);
	Control_Laws(method,muy_theta.NB,muy_thetadot.NS,PB);
	Control_Laws(method,muy_theta.NB,muy_thetadot.ZE,PM);
	Control_Laws(method,muy_theta.NB,muy_thetadot.PS,PS);
	Control_Laws(method,muy_theta.NB,muy_thetadot.PB,PS);
	
	Control_Laws(method,muy_theta.NS,muy_thetadot.NB,PM);
	Control_Laws(method,muy_theta.NS,muy_thetadot.NS,PM);
	Control_Laws(method,muy_theta.NS,muy_thetadot.ZE,PS);
	Control_Laws(method,muy_theta.NS,muy_thetadot.PS,ZE);
	Control_Laws(method,muy_theta.NS,muy_thetadot.PB,NS);
	
	Control_Laws(method,muy_theta.ZE,muy_thetadot.NB,PS);
	Control_Laws(method,muy_theta.ZE,muy_thetadot.NS,PS);
	Control_Laws(method,muy_theta.ZE,muy_thetadot.ZE,ZE);
	Control_Laws(method,muy_theta.ZE,muy_thetadot.PS,NS);
	Control_Laws(method,muy_theta.ZE,muy_thetadot.PB,NS);
	
	Control_Laws(method,muy_theta.PS,muy_thetadot.NB,PS);
	Control_Laws(method,muy_theta.PS,muy_thetadot.NS,ZE);
	Control_Laws(method,muy_theta.PS,muy_thetadot.ZE,NS);
	Control_Laws(method,muy_theta.PS,muy_thetadot.PS,NM);
	Control_Laws(method,muy_theta.PS,muy_thetadot.PB,NM);
	
	Control_Laws(method,muy_theta.PB,muy_thetadot.NB,NS);
	Control_Laws(method,muy_theta.PB,muy_thetadot.NS,NS);
	Control_Laws(method,muy_theta.PB,muy_thetadot.ZE,NM);
	Control_Laws(method,muy_theta.PB,muy_thetadot.PS,NB);
	Control_Laws(method,muy_theta.PB,muy_thetadot.PB,NVB);
	
	double TS = sum.NVB*offset.NVB + sum.PVB*offset.PVB +
							sum.NB*offset.NB + sum.PB*offset.PB +
							sum.NM*offset.NM + sum.PM*offset.PM +
							sum.NS*offset.NS + sum.PS*offset.PS +
							sum.ZE*offset.ZE;
	double MS = sum.NVB + sum.NB + sum.NM + sum.NS + sum.ZE +
							sum.PVB + sum.PB + sum.PM + sum.PS;
	return (float)(TS/MS);
}

static void Filter_In(float &x1, float &x2)
{
	if(x1 <= THETA_MIN)
	{
		x1 = THETA_MIN;
	}
	else if(x1 >= THETA_MAX)
	{
		x1 = THETA_MAX;
	}
	if(x2 <= THETADOT_MIN)
	{
		x2 = THETADOT_MIN;
	}
	else if(x2 >= THETADOT_MAX)
	{
		x2 = THETADOT_MAX;
	}
	x1 = x1/45;
	x2 = x2/15;
}

static float Filter_Out(float x)
{
	x = x*Ku;

    return x;
// 	float zero_level = 0.05*Ku;
// 	if(x > -zero_level && x < zero_level)
// 	{
// 		return 0;
// 	}
// 	else
// 	{
// 		if(x < 0)
// 			return -Fuzzy_Map(-x,zero_level,Ku,speed_mass_min,Ku);
// 		else
// 			return Fuzzy_Map(x,zero_level,Ku,speed_mass_min,Ku);
// 	}
}


static void Reset_Value(void)
{
	muy_offset.NVB = 0;
	muy_offset.NB = 0;
	muy_offset.NM = 0;
	muy_offset.NS = 0;
	muy_offset.ZE = 0;
	muy_offset.PS = 0;
	muy_offset.PM = 0;
	muy_offset.PB = 0;
	muy_offset.PVB = 0;
	
	sum.NVB = 0;
	sum.NB = 0;
	sum.NM = 0;
	sum.NS = 0;
	sum.ZE = 0;
	sum.PS = 0;
	sum.PM = 0;
	sum.PB = 0;
	sum.PVB = 0;
}

float Balance_Operation(float Xsen_Pitch_Radian)
{
	_sample_count --;
	// if(!_sample_count)
	// {
	// 	theta_in = Fuzzy_Map(Xsen_Pitch_Radian,Xsen_Min,Xsen_Max,THETA_MIN,THETA_MAX);
	// 	thetadot_in = x2xdot(theta_in, pre_theta_in);
	// 	Filter_In(theta_in, thetadot_in);
	// 	//Fuzzy Logic Controller
	// 	//************************************************
	// 	Fuzzy_Result(theta_filtered, theta_dot_filetered);
	// 	offset_defuzzy = Defuzzy_Result(MAX_PROD);
	// 	//************************************************
	// 	// if(first_data_pass)
	// 	// 	first_data_pass = false;
	// 	// else
	// 	// {
		
	// 	// 	UCAN_Run_Mass(offset_out.value);
	// 	// }
	// 	pre_theta_in = theta_in;
	// 	Reset_Value();
	// 	_sample_count = SAMPLE_TIME/20.0;
	// 	offset_out.value = Filter_Out(offset_defuzzy);
	// 	mass_position += offset_out.value;
	// 	if (mass_position > 200)
	// 	mass_position  =  200;
	// 	if (mass_position > -200)
	// 	mass_position  =  -200;
	// }
	Membership_Function_Declaration();
	void(*ptrFitlerIn) (float &, float &) = Filter_In;
	theta_in = Fuzzy_Map(Xsen_Pitch_Radian,Xsen_Min,Xsen_Max,THETA_MIN,THETA_MAX);
	thetadot_in = x2xdot(theta_in, pre_theta_in);
	pre_theta_in = theta_in;
	(*ptrFitlerIn)(theta_in, thetadot_in);
		//Fuzzy Logic Controller
		//************************************************
	Fuzzy_Result(theta_in, thetadot_in);
	offset_defuzzy = Defuzzy_Result(MAX_PROD);
	//printf( "%f \n", Defuzzy_Result(MAX_PROD));
		//************************************************
		// if(first_data_pass)
		// 	first_data_pass = false;
		// else
		// {
		
		// 	UCAN_Run_Mass(offset_out.value);
		// }
	Reset_Value();
	_sample_count = SAMPLE_TIME/20.0;
	offset_out.value = Filter_Out(offset_defuzzy);
	mass_position += -offset_out.value;
	if (mass_position > 198)
	mass_position  =  198;
	if (mass_position < -198)
	mass_position  =  -198;
	//printf("%f , %f, %f, %f , %f \n", theta_in, thetadot_in, muy_theta.NB, muy_theta.PS,muy_theta.PB  );
	//printf("%f\n ",mass_position);
	return mass_position;
}
