#include "Glider.h"

void Glider_calc(double z1, double z2, double z)
{
  if (Glider_down)
  {
    Glider_xp1 = 0.8;
    Glider_theta1 = -0.785;
  }
  else
  {
    Glider_xp1 = 0;
    Glider_theta1 = 0.785;
  }

  if ( z > (z2 - 0.1))
  {
    Glider_down = false;
  }
  else if ( z < (z1 + 0.1))
  {
    Glider_down = true;
  }
}
