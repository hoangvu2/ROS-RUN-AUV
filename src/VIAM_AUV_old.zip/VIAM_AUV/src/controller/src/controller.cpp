#include "controller.h"

#include <cmath>
#include "fuzzyMass_shifter.cpp"

Controller::Controller()
{
  ros::NodeHandle private_nh("~");
  private_nh.getParam("controlling_period", controlling_period);
  private_nh.getParam("avg_rpm", avg_rpm);
  private_nh.getParam("speed_Kp", speedPID.Kp);
  private_nh.getParam("speed_Ki", speedPID.Ki);
  private_nh.getParam("speed_Kd", speedPID.Kd);
  private_nh.getParam("heading_Kp", headingPID.Kp);
  private_nh.getParam("heading_Ki", headingPID.Ki);
  private_nh.getParam("heading_Kd", headingPID.Kd);
  private_nh.getParam("pitch_Kp", pitchPID.Kp);
  private_nh.getParam("pitch_Ki", pitchPID.Ki);
  private_nh.getParam("pitch_Kd", pitchPID.Kd);

   ros::NodeHandle nh;
  pubMotorsCmd = nh.advertise<MotorsCommand>("motors/cmd", 1);
  subOdom = nh.subscribe("odom", 10, &Controller::onOdomCallBack, this);
  subSetpoint = nh.subscribe("setpoint", 10, &Controller::onSetpointCallBack, this);
  loopControl = nh.createTimer(ros::Duration(controlling_period), &Controller::onControlLoop, this);

  resSetSpeedPID = nh.advertiseService("parameter/set_speed_PID", &Controller::onSetSpeedPIDCallBack, this);
  resGetSpeedPID = nh.advertiseService("parameter/get_speed_PID", &Controller::onGetSpeedPIDCallBack, this);
  resSetHeadingPID = nh.advertiseService("parameter/set_heading_PID", &Controller::onSetHeadingPIDCallBack, this);
  resGetHeadingPID = nh.advertiseService("parameter/get_heading_PID", &Controller::onGetHeadingPIDCallBack, this);
  resSetPitchPID = nh.advertiseService("parameter/set_pitch_PID", &Controller::onSetPitchPIDCallBack, this);
  resGetPitchPID = nh.advertiseService("parameter/get_pitch_PID", &Controller::onGetPitchPIDCallBack, this);

  lastControlUpdateTime = lastSetpointTime = ros::Time::now();
  speedPID.threshold = avg_rpm;
  headingPID.threshold = 60.0;
  pitchPID.threshold = 190;
}

Controller::~Controller()
{
  if (ros::isStarted())
  {
    ros::shutdown();
    ros::waitForShutdown();
  }
}

void Controller::onOdomCallBack(const Odometry::ConstPtr& msg)
{
  std::unique_lock<std::mutex> lock(mutex);

  currSpeed = msg->linear_velocity.x;
  currHeading = msg->orientation.z;
  currPitch = msg->orientation.y;
  currDepth = msg->position.z;
  
}

void Controller::onSetpointCallBack(const Setpoint::ConstPtr& msg)
{
  std::unique_lock<std::mutex> lock(mutex);

  lastSetpointTime = msg->header.stamp;
  desiredSpeed = msg->linear_velocity.x;
  desiredHeading = msg->orientation.z;
  desiredPitch = msg->orientation.y;
}

void Controller::onControlLoop(const ros::TimerEvent& event)
{
  std::unique_lock<std::mutex> lock(mutex);

  double dtc = (event.current_real - lastSetpointTime).toSec();
  if (dtc > 0.5)
    return;
  bool check = false;
  double dt = event.current_real.toSec() - lastControlUpdateTime.toSec();
  speedPID.error = desiredSpeed - currSpeed;
  speedPID.Ts = dt;
  speedPID.runPID();
  headingPID.error = atan2(sin(desiredHeading - currHeading), cos(desiredHeading - currHeading));
  headingPID.Ts = dt;
  headingPID.runPID();
  pitchPID.error = desiredPitch - currPitch;
  pitchPID.Ts = dt;
  pitchPID.runPID();
  if (pitchPID.output != 0)
	  check = true;
	
  MotorsCommand motorsMsg;
  motorsMsg.header.stamp = event.current_real;
  motorsMsg.rudder_angle = headingPID.output;
  motorsMsg.piston_position = 0;
  motorsMsg.mass_shifter_position = 0;
  if(desiredSpeed != 0 )
  {
    motorsMsg.thruster_speed = avg_rpm + speedPID.output;
    motorsMsg.mass_shifter_position = pitchPID.output;
  } 
  if (desiredSpeed ==0) 
  {
    if (end_process == false)
    {
      
      for(count = 0; count<6;count++)
      {
        motorsMsg.thruster_speed = count*100;
        pubMotorsCmd.publish(motorsMsg);
        ros::Duration(0.5).sleep();
      }
      count = count -1;
      end_process = true;
    }
    if ((currDepth < 0.4)&&(Glider_down==false)) 
      {
      motorsMsg.thruster_speed = count*100;
        motorsMsg.mass_shifter_position = 150;
      }
    else
      {
      //motorsMsg.mass_shifter_position = pitchPID.output;
      // if (abs(pitchPID.output) <= 100 )
      // {
      //   count_pid++;
      // }  
      motorsMsg.mass_shifter_position = -150;
      Glider_down = true;
      motorsMsg.thruster_speed = count*100;
      }
    if ((currDepth <0.2) && (Glider_down)) //&& (count_pid == 50)
    {
      motorsMsg.mass_shifter_position = 0;
      if (start_process==false)
      {
      for( count = 6; count >= 0;count--)
      {
        motorsMsg.thruster_speed = count*100;
        pubMotorsCmd.publish(motorsMsg);
        ros::Duration(0.5).sleep();
      }
      start_process = true;
      }
    }
    
 
  }
pubMotorsCmd.publish(motorsMsg);
  
  lastControlUpdateTime = event.current_real;
}

bool Controller::onSetSpeedPIDCallBack(ParamSetRequest& req, ParamSetResponse& res)
{
  res.success = false;

  if (compareString(req.param_id.data(), "speed_Kp"))
  {
    speedPID.Kp = req.value.real;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "speed_Ki"))
  {
    speedPID.Ki = req.value.real;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "speed_Kd"))
  {
    speedPID.Kd = req.value.real;
    res.success = true;
  }

  res.value.real = req.value.real;
  return res.success;
}

bool Controller::onGetSpeedPIDCallBack(ParamGetRequest& req, ParamGetResponse& res)
{
  res.success = false;

  if (compareString(req.param_id.data(), "speed_Kp"))
  {
    res.value.real = speedPID.Kp;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "speed_Ki"))
  {
    res.value.real = speedPID.Ki;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "speed_Kd"))
  {
    res.value.real = speedPID.Kd;
    res.success = true;
  }

  return res.success;
}

bool Controller::onSetHeadingPIDCallBack(ParamSetRequest& req, ParamSetResponse& res)
{
  res.success = false;

  if (compareString(req.param_id.data(), "heading_Kp"))
  {
    headingPID.Kp = req.value.real;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Ki"))
  {
    headingPID.Ki = req.value.real;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Kd"))
  {
    headingPID.Kd = req.value.real;
    res.success = true;
  }

  res.value.real = req.value.real;
  return res.success;
}

bool Controller::onGetHeadingPIDCallBack(ParamGetRequest& req, ParamGetResponse& res)
{
  res.success = false;

  if (compareString(req.param_id.data(), "heading_Kp"))
  {
    res.value.real = headingPID.Kp;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Ki"))
  {
    res.value.real = headingPID.Ki;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Kd"))
  {
    res.value.real = headingPID.Kd;
    res.success = true;
  }

  return res.success;
}

bool Controller::onSetPitchPIDCallBack(ParamSetRequest& req, ParamSetResponse& res)
{
  res.success = false;

  if (compareString(req.param_id.data(), "heading_Kp"))
  {
    headingPID.Kp = req.value.real;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Ki"))
  {
    headingPID.Ki = req.value.real;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Kd"))
  {
    headingPID.Kd = req.value.real;
    res.success = true;
  }

  res.value.real = req.value.real;
  return res.success;
}

bool Controller::onGetPitchPIDCallBack(ParamGetRequest& req, ParamGetResponse& res)
{
  res.success = false;

  if (compareString(req.param_id.data(), "heading_Kp"))
  {
    res.value.real = headingPID.Kp;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Ki"))
  {
    res.value.real = headingPID.Ki;
    res.success = true;
  }
  if (compareString(req.param_id.data(), "heading_Kd"))
  {
    res.value.real = headingPID.Kd;
    res.success = true;
  }

  return res.success;
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "controller");
  Controller control;
  ros::spin();
}
