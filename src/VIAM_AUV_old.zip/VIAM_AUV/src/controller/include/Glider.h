#ifndef GLIDER_H
#define GLIDER_H

double Glider_theta1;
double Glider_xp1;
bool Glider_down = true;
//double gliderOffset ;
//double gliderXp;
//double gliderTheta;
  
void Glider_calc(double z1, double z2, double z);

#endif  // GLIDER_H
