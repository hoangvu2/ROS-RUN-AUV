#ifndef _MY_BALANCE_H_
#define _MY_BALANCE_H_

#include "stdint.h"
typedef enum
{
	NVB = -4,
	NB = -3,
	NM = -2,
	NS = -1,
	ZE = 0,
	PS = 1,
	PM = 2,
	PB = 3,
	PVB = 4
}Fuzzy_DataTypeDef;

typedef enum
{
	MAX_MIN = 0,
	MAX_PROD = 1
}Defuzzy_And_Or_Method;

//PP giai mo: trung binh co trong so

union Data_In
{
	float value;
	struct
	{
		uint8_t byte1;
		uint8_t byte2;
		uint8_t byte3;
		uint8_t byte4;
	}byte;
};
extern union Data_In xsen_angle_in, offset_out;

extern float SAMPLE_TIME;	
extern float speed_mass_min;
extern float Xsen_Min;
extern float Xsen_Max;
extern float THETA_MIN;		
extern float THETA_MAX;
extern float THETADOT_MIN;		
extern float THETADOT_MAX;
extern float K1;
extern float K2;
extern float Ku;
extern float mass_position;


void Algorithm_Config(void);
void Membership_Function_Declaration(void);
float x2xdot(float x, float pre_x);
void Fuzzy_Result(double x1, double x2);
float Defuzzy_Result(Defuzzy_And_Or_Method method);
float Balance_Operation(float Xsen_Pitch_Radian);

#endif
